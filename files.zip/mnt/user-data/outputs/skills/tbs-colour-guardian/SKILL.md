---
name: tbs-colour-guardian
description: Enforce and apply The Blue Space colour guidelines when reviewing, generating, or editing UI code, design tokens, CSS, component styles, ecommerce pages, and product-related interfaces. Use this skill when working in Claude Code or with teammates on frontend implementation, design QA, accessibility checks, hover states, state colours, token mapping, or brand-colour decisions so outputs stay on-brand, consistent, and implementation-ready.
---

# The Blue Space Colour Guardian

Turn the brand colour guidelines into practical implementation rules for UI work, code reviews, design QA, and token generation.

## Core rule

Preserve brand consistency first. Do not invent new primary colours, swap semantic meanings, or use accent colours heavily unless the request explicitly overrides the guideline.

## Non-negotiable brand rules

- Treat `#071A2D` as the most important brand action colour.
- Use `#071A2D` for primary purchase-related CTAs only — Add to Cart, Buy Now, checkout actions, cart-related UI.
- Do not reuse `#071A2D` casually for unrelated decorative UI.
- Keep cart-related elements visually tied to the primary blue system.
- Use supporting colours mainly for backgrounds, secondary surfaces, borders, inactive states, supporting text.
- Use accent colours sparingly and strategically.
- Maintain accessible contrast. Prefer combinations meeting at least WCAG 2.1 AA for normal text.

## Approved palette

### Core brand colours

| Token | Hex | Purpose |
|---|---|---|
| `brand.blue` | `#354E66` | Primary interactive blue, links on brand surfaces, secondary CTAs |
| `brand.blue.light` | `#6989A3` | Soft brand accents, decorative fills |
| `brand.blue.dark` | `#071A2D` | **Purchase-critical CTAs only**, dark surfaces, primary text |

### Supporting colours

| Token | Hex | Purpose |
|---|---|---|
| `support.bluegrey.100` | `#C5D0D8` | Dividers on dark, light accent shapes |
| `support.grey.050` | `#F2F2F2` | Muted surface |
| `support.offwhite` | `#F7F8F9` | Default light section background |

### Secondary families

All available in 100/200/300/400 steps. Use 100/200 for surfaces, 300/400 for text/icons on light backgrounds.

- **Red:** `#F7F5F5` → `#E8E1E1` → `#A77F7A` → `#804A43`
- **Brown:** `#EFEDE8` → `#E5E1D8` → `#C1B69A` → `#685D41`
- **Green:** `#F3F4ED` → `#C7CEBF` → `#84896E` → `#3E4E46`
- **Charcoal:** `#EAF0F0` → `#C8CFD0` → `#58676E` → `#2E4853`
- **Orange:** `#F7EDE3` → `#EAC7A4` → `#B87F4A` → `#734314`

### Neutral greys

| Token | Hex | Default usage |
|---|---|---|
| `grey.300` | `#E0E0E0` | Dividers, card edges, tertiary text, hints |
| `grey.400` | `#BDBDBD` | Borders, disabled buttons, muted states |
| `grey.600` | `#757575` | Secondary text, icons, labels |
| `grey.900` | `#212121` | Primary text on light surfaces |

### Semantic state colours

| State | Dark | Main | Light |
|---|---|---|---|
| Info / underlined text | `#125DA6` | `#1776D3` | `#509FEC` |
| Warning | `#C05802` | `#ED6C02` | `#FD8F35` |
| Error / danger | `#A82424` | `#D22D2D` | `#DB5757` |
| Success | `#27682A` | `#3FAB45` | `#6AC86F` |

## Hover and interaction rules

Always provide a visible hover state for interactive elements.

For primary blue interactions:

- default: `#354E66`
- hover: `#2F465C`
- pressed / active: `#2A3E50`

For `#071A2D` purchase CTAs:

- hover: `#10293F` (slight lift) or darken-by-filter, preserving perceived weight
- pressed: `#2A3E50`

When exact hover values are not given for other colours, darken subtly without making the state noisy or off-brand.

## Behaviour rules

When generating or reviewing code:

1. Map requested colours to the approved palette before writing code.
2. Prefer tokens or CSS variables over hardcoded hex values.
3. Flag off-brand colours and replace with the closest approved token.
4. Preserve semantic meaning:
   - primary purchase action → `#071A2D`
   - informational link or info state → blue semantic set
   - warning → orange semantic set
   - error → red semantic set
   - success → green semantic set
5. Keep decorative colour usage restrained so product visuals and CTAs remain dominant.
6. Check contrast before approving text/background combinations.
7. For disabled or inactive UI, prefer neutral greys instead of saturated colours.
8. For backgrounds and section fills, prefer off-whites, light greys, and low-saturation supporting tones.

## Preferred output modes

### Code patch mode

Return implementation-ready code with variables:

```css
:root {
  --tbs-brand-blue: #354E66;
  --tbs-brand-blue-light: #6989A3;
  --tbs-brand-blue-dark: #071A2D;
  --tbs-hover-blue: #2F465C;
  --tbs-active-blue: #2A3E50;
  --tbs-purchase-primary: #071A2D;
}
```

### Review mode

Return:
- what is compliant
- what is not compliant
- exact replacements
- accessibility risks
- a corrected snippet when helpful

### Token mode

Return JSON, CSS variables, Tailwind theme extensions, or design-token objects using the approved names.

### Teammate handoff mode

When the user needs something shareable:
- decision
- rationale
- approved hex or token
- implementation note
- accessibility note if relevant

## Review checklist

Before finalising:

- [ ] No unapproved primary colour replaces `#071A2D` for purchase-critical actions
- [ ] Cart and checkout UI remain in the primary blue family
- [ ] Accent colours are limited and intentional
- [ ] Hover states exist for interactive controls
- [ ] Disabled states use muted neutrals
- [ ] State colours match semantic meaning
- [ ] Text contrast is acceptable
- [ ] Output is ready for a developer or designer to use immediately

## Response style

Be decisive and practical.

- Do not give abstract colour theory unless asked.
- Prefer exact replacements over vague suggestions.
- When multiple options exist, recommend one default and list the fallback.
- Keep teammate-facing explanations brief and implementation-oriented.
